
Book Club instalation instructions.

Place the unzipped package into your directory in the location where you would like for the program to reside, typically in Program Files. If you have not installed a program that uses Visual C before run the VC_redist.x64.exe which is the redistributable installer provided by Microsoft for running Visual C programs. Now create a shortcut for Book Club.exe to your start menu, taskbar, or desktop to complete the setup process. Your setup is complete. Click on the Book Club.exe shortcut to use the program.   